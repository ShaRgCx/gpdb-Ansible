---
title: Unloading File Data Using Greenplum Streaming Server
---

Starting from version 1.11.0, Greenplum Streaming Server allows you to unload data from Greenplum Database into a file in the host where Greenplum Streaming Server is running. 

Refer to the [Greenplum Streaming Server](https://docs.vmware.com/en/VMware-Greenplum-Streaming-Server/1.11/greenplum-streaming-server/file-unloading.html) documentation for more details.

**Parent topic:** [Unloading Data from Greenplum Database](../../load/topics/g-unloading-data-from-greenplum-database.html)
