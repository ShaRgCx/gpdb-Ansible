---
title: Example 10—Readable and Writable External Tables with XML Transformations 
---

Greenplum Database can read and write XML data to and from external tables with gpfdist. For information about setting up an XML transform, see [Transforming External Data with gpfdist and gpload](../load/topics/transforming-xml-data.html).

**Parent topic:** [Examples for Creating External Tables](../external/g-creating-external-tables---examples.html)

