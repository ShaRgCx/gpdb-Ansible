# gp\_exttable\_fdw

The `gp_exttable_fdw` module is a built-in foreign-data wrapper that converts an external table to a foreign table.

Refer to [Understanding the External Table to Foreign Table Mapping](../../admin_guide/external/map_ext_to_foreign.html) for more information about the conversion and runtime implications.

> **Important** Do not register nor directly use the `gp_exttable_fdw` module.

